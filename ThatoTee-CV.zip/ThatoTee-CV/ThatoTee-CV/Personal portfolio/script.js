const downloadBtn = document.querySelector(".download-btn");

downloadBtn.addEventListener("click" , () =>{
    print();
});